/**
 * @file  course.h 
 * @author Ryan Kang
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief This is the struct for course, it includes the name, code, students taking the course, and total number of students.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Functions to enroll a student, print out course information, find the top student, and create a list of all passing students.
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


